// PWA Bootstrap - dynamically inject manifest and register service worker
(function(){
  // Inject manifest link
  var link = document.createElement('link');
  link.rel = 'manifest';
  link.href = 'manifest.json';
  document.head.appendChild(link);

  // Inject apple-touch-icon
  var icon = document.createElement('link');
  icon.rel = 'apple-touch-icon';
  icon.href = 'apple-touch-icon.png';
  document.head.appendChild(icon);

  // Inject favicon
  var fav = document.createElement('link');
  fav.rel = 'icon';
  fav.type = 'image/png';
  fav.sizes = '32x32';
  fav.href = 'favicon.png';
  document.head.appendChild(fav);

  // Inject theme-color
  var theme = document.createElement('meta');
  theme.name = 'theme-color';
  theme.content = '#c4868e';
  document.head.appendChild(theme);

  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(function(e) {
      console.log('SW registration failed:', e);
    });
  }
})();
