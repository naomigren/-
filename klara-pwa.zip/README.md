# 克拉拉养成计划 PWA 安装包

## 上传到 GitHub 的步骤：

1. 在 GitHub 创建一个新 repo（比如叫 `klara-quest`）
2. 把这个文件夹里的 **所有文件** 上传到 repo 根目录
3. 把你的 `klara-quest.html` 也上传到**同一个目录**（不要改名）
4. 去 repo 的 Settings → Pages → Source 选 `main` branch → Save
5. 等1-2分钟，GitHub 会给你一个链接，比如 `https://你的用户名.github.io/klara-quest/`
6. 用手机打开这个链接
7. iOS: 点分享按钮 → "添加到主屏幕"
8. Android: 浏览器会自动弹出"安装应用"提示

## 文件清单：
- `index.html` - PWA 入口页（自动加载 klara-quest.html）
- `manifest.json` - PWA 配置文件（图标、名称等）
- `sw.js` - Service Worker（离线缓存）
- `pwa.js` - PWA 初始化脚本
- `icon-192x192.png` - Android 图标
- `icon-512x512.png` - 高清图标
- `apple-touch-icon.png` - iOS 图标
- `favicon.png` - 浏览器标签图标

⚠️ 不要忘记把 `klara-quest.html` 也上传！
